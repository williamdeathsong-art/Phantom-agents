Phantom Final - Definitive GitHub-ready project
----------------------------------------------

Contents:
- Full Android app source in app/src/main/java/...
- assets/hallucinations.json (curated)
- assets/scream.wav (local)
- res/drawable/flash.png
- Gradle build files and GitHub Actions workflow that builds the APK and uploads artifact

Usage (Moto G, no Android Studio):
1. Create GitHub repo (private preferred).
2. Upload all files from this ZIP to the repo root (commit to main).
3. Go to Actions tab; the workflow 'Build APK (robust)' will run automatically.
4. When it completes, download artifact 'app-debug-apk' and sideload on your Moto G.
5. Run app, read consent, grant permissions if desired, start simulation.

Acceptance checklist (smoke tests):
- App installs and opens to consent screen.
- Starting simulation creates a foreground notification and begins events.
- Hallucination overlays appear semi-randomly and escalate toward 55-60 minutes.
- Final climax plays scream.wav and shows full-screen flash.
- On stop, cache is purged and Debrief shows confirmation.

If the Actions run fails, copy the full console output of the failed step and paste it back here; I will diagnose and repackage immediately.
