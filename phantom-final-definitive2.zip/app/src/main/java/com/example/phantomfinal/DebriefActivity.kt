package com.example.phantomfinal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class DebriefActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Column(modifier=Modifier.fillMaxSize().padding(18.dp)) { Text("Session Summary — Simulation Complete"); Spacer(modifier=Modifier.height(8.dp)); Text("All ephemeral buffers purged. No upload occurred.") } } }
    }
}
