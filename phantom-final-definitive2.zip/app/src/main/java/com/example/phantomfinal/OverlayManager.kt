package com.example.phantomfinal

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import kotlinx.coroutines.*
import androidx.core.content.ContextCompat

class OverlayManager(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = CoroutineScope(Dispatchers.Main)
    fun showAutocorrectFlicker(text:String,x:Int=100,y:Int=400,durationMs:Long=150) {
        ui.launch {
            val tv = android.widget.TextView(ctx).apply { setTextAppearance(android.R.style.TextAppearance_Medium); setText(text); setBackgroundColor(Color.TRANSPARENT); setTextColor(0xFF9E9E9E.toInt()) }
            val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            params.gravity = Gravity.TOP or Gravity.START; params.x = x; params.y = y
            try { wm.addView(tv, params); delay(durationMs) } catch (e:Exception) {} finally { try { wm.removeView(tv) } catch (_:Exception) {} }
        }
    }
    fun showTransientLog(text:String,durationMs:Long=900) { android.widget.Toast.makeText(ctx, text, android.widget.Toast.LENGTH_SHORT).show() }
    fun showFullScreenFlash(durationMs:Long=1200L) {
        ui.launch {
            val iv = ImageView(ctx)
            try {
                val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_FULLSCREEN, PixelFormat.OPAQUE)
                params.gravity = Gravity.CENTER; iv.setBackgroundColor(Color.WHITE)
                try { val d = ContextCompat.getDrawable(ctx, ctx.resources.getIdentifier("flash","drawable", ctx.packageName)); if (d!=null) iv.setImageDrawable(d) } catch (_:Exception) {}
                wm.addView(iv, params); delay(durationMs)
            } catch (e:Exception) {} finally { try { wm.removeView(iv) } catch (_:Exception) {} }
        }
    }
}
