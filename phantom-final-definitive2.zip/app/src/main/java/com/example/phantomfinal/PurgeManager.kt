package com.example.phantomfinal

import android.content.Context

class PurgeManager(private val ctx: Context) {
    fun purgeAll() {
        try { val cache = ctx.cacheDir; cache.listFiles()?.forEach{ it.delete() } } catch (_:Exception) {}
    }
}
