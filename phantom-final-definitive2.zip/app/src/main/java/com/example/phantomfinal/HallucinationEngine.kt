package com.example.phantomfinal

import android.content.Context
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream

class HallucinationEngine(private val ctx: Context, private val overlay: OverlayManager) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val catalog = mutableListOf<JSONObject>()
    private val used = mutableSetOf<String>()
    private val maxPerSession = 80
    init { load() }
    private fun load() {
        try {
            val ins: InputStream = ctx.assets.open("hallucinations.json")
            val text = ins.reader().readText()
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) catalog.add(arr.getJSONObject(i))
        } catch (e: Exception) { val o=JSONObject(); o.put("id","d1"); o.put("phrase","did you mean: coffin?"); catalog.add(o) }
    }
    fun fireProceduralHallucination(signals: Map<String, Any>) {
        scope.launch {
            val candidates = catalog.filter { c -> val ctxs=(c.optString("context","")) .split(","); val typing = signals["typing"] as? Boolean ?: false; if (ctxs.contains("typing") && typing) true else ctxs.isEmpty() || ctxs.contains("any") }.shuffled()
            val pick = candidates.firstOrNull { !used.contains(it.optString("id")) }
            if (pick != null && used.size < maxPerSession) {
                used.add(pick.optString("id"))
                val phrase = pick.optString("phrase")
                overlay.showAutocorrectFlicker(phrase, x=(120..420).random(), y=(200..800).random(), durationMs=(100..450).random().toLong())
                val follow = pick.optString("followup","");
                if (follow.isNotBlank()) { delay((5000L..14000L).random()); overlay.showTransientLog(follow) }
            }
        }
    }
}
