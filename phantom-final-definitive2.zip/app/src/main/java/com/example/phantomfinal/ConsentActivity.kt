package com.example.phantomfinal

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.setContent
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.widget.Toast

class ConsentActivity : AppCompatActivity() {
    private val requiredPermissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
    private var overlayPermissionGranted by mutableStateOf(false)
    private var cameraGranted by mutableStateOf(false)
    private var micGranted by mutableStateOf(false)
    private val reqPermLauncher = registerForActivityResult(RequestMultiplePermissions()) { results ->
        cameraGranted = results[Manifest.permission.CAMERA] == true
        micGranted = results[Manifest.permission.RECORD_AUDIO] == true
        if (!cameraGranted && !micGranted) {
            Toast.makeText(this, "Camera or Microphone required for full experience. You can continue simulated-only.", Toast.LENGTH_LONG).show()
        }
    }
    private val overlayIntentLauncher = registerForActivityResult(StartActivityForResult()) { overlayPermissionGranted = Settings.canDrawOverlays(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overlayPermissionGranted = Settings.canDrawOverlays(this)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(modifier = Modifier.fillMaxSize().padding(18.dp).verticalScroll(rememberScrollState())) {
                        Text(text = "Phantom Simulation — Consent & Permissions", style = MaterialTheme.typography.headlineSmall)
                        Text(text = "Local-only simulation using short camera preview and microphone buffers to craft ephemeral hallucinations. Nothing is uploaded.")
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { reqPermLauncher.launch(requiredPermissions) }) { Text("Grant Camera & Microphone") }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                            overlayIntentLauncher.launch(intent)
                        }) { Text("Enable Overlay (optional)") }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = {
                            val svc = Intent(this@ConsentActivity, SimulationService::class.java)
                            ContextCompat.startForegroundService(this@ConsentActivity, svc)
                            finish()
                        }) { Text("Start Simulation (I consent)") }
                    }
                }
            }
        }
    }
}
