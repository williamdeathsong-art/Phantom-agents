package com.example.phantomfinal

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class SimulationService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private lateinit var trigger: TriggerEngine
    private lateinit var hallucination: HallucinationEngine
    private lateinit var overlay: OverlayManager
    private lateinit var camera: CameraPreview
    private lateinit var audio: AudioBuffer
    private lateinit var climax: ClimaxManager
    private val SESSION_MAX = 60*60*1000L
    private val CLIMAX_MIN = 55*60*1000L
    private val CLIMAX_MAX = 60*60*1000L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, buildNotification())
        overlay = OverlayManager(this)
        hallucination = HallucinationEngine(this, overlay)
        trigger = TriggerEngine(this, hallucination)
        camera = CameraPreview(this, trigger)
        audio = AudioBuffer(this, trigger)
        climax = ClimaxManager(overlay, assets)
        camera.startPreviewIfPermitted()
        audio.startIfPermitted()
        scope.launch {
            delay(10000L)
            trigger.start()
            val offset = (CLIMAX_MIN..CLIMAX_MAX).random()
            delay(offset)
            climax.triggerClimax()
            delay(SESSION_MAX - offset)
            stopSelf()
        }
    }
    private fun buildNotification(): Notification {
        val i = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this,0,i, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "sim").setContentTitle("Phantom Simulation").setContentText("Running...").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pi).build()
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("sim", "Simulation", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { super.onDestroy(); trigger.stop(); camera.stop(); audio.stop() }
}
