package com.example.phantomfinal

import android.content.Context
import kotlinx.coroutines.*
import androidx.camera.lifecycle.ProcessCameraProvider

class CameraPreview(private val ctx: Context, private val trigger: TriggerEngine) {
    private var provider: ProcessCameraProvider? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    fun startPreviewIfPermitted() = scope.launch {
        try { val f = ProcessCameraProvider.getInstance(ctx); provider = f.get(); trigger.onCamera(true) } catch (_:Exception) {}
    }
    fun stop() { try { provider?.unbindAll(); trigger.onCamera(false) } catch (_:Exception) {} }
}
