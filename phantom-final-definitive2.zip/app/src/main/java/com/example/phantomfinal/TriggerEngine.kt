package com.example.phantomfinal

import kotlinx.coroutines.*
import kotlin.random.Random

class TriggerEngine(private val ctx: android.content.Context, private val hallucination: HallucinationEngine) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var running = false
    private var lastTyping = 0L
    private var ambientSilent = false
    private var cameraActive = false
    fun start() { running = true; scope.launch { while(running) { evaluate(); delay(1000L) } } }
    fun stop() { running = false; scope.cancel() }
    fun onTyping() { lastTyping = System.currentTimeMillis() }
    fun onAmbientSilent(s:Boolean) { ambientSilent = s }
    fun onCamera(a:Boolean) { cameraActive = a }
    private suspend fun evaluate() {
        val now = System.currentTimeMillis()
        val typingRecent = (now - lastTyping) < 2500
        val base = if (typingRecent) 0.4 else 0.06
        val silence = if (ambientSilent) 0.28 else 0.0
        val cam = if (cameraActive) 0.18 else 0.0
        val score = base + silence + cam + Random.nextDouble(-0.05,0.05)
        if (score > 0.40) hallucination.fireProceduralHallucination(mapOf("typing" to typingRecent, "ambient" to ambientSilent, "camera" to cameraActive))
    }
}
