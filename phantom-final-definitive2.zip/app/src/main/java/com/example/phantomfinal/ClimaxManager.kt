package com.example.phantomfinal

import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlinx.coroutines.*

class ClimaxManager(private val overlay: OverlayManager, private val assets: android.content.res.AssetManager) {
    private val scope = CoroutineScope(Dispatchers.Main)
    private var player: MediaPlayer? = null
    fun triggerClimax() {
        scope.launch {
            try {
                val afd: AssetFileDescriptor = assets.openFd("scream.wav")
                player = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    isLooping = false; prepare(); setVolume(1.0f,1.0f); start()
                }
            } catch (_:Exception) {}
            overlay.showFullScreenFlash()
            delay(1400L)
            try{ player?.stop(); player?.release() } catch(_:Exception) {}
        }
    }
}
