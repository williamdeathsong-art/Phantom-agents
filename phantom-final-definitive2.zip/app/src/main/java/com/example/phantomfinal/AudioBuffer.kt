package com.example.phantomfinal

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.*

class AudioBuffer(private val ctx: Context, private val trigger: TriggerEngine) {
    private var recording = false
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var audioRecord: AudioRecord? = null
    private val sampleRate = 16000
    private val bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
    fun startIfPermitted() {
        try {
            audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
            audioRecord?.startRecording()
            recording = true
            scope.launch {
                val buf = ShortArray(1024); var pos=0
                while (recording) {
                    val r = audioRecord?.read(buf,0,buf.size) ?: 0
                    if (r>0) { for(i in 0 until r){ buf.getOrNull(i)?.let{ /* store */ }; pos=(pos+1)% (sampleRate*3) } }
                    var sum=0L; for(i in 0 until 1024) sum += Math.abs(buf.getOrNull(i)?.toInt() ?: 0)
                    val avg = sum/1024; if (avg < 200) trigger.onAmbientSilent(true) else trigger.onAmbientSilent(false)
                    delay(200L)
                }
            }
        } catch (_:Exception) {}
    }
    fun stop() { recording=false; try{ audioRecord?.stop(); audioRecord?.release() } catch(_:Exception){}; scope.cancel() }
}
